<?php
/*
Plugin Name: Custom E-Commerce Plugin
Description: A custom e-commerce plugin with all products, cart, and orders functionality.
Version: 1.0
Author: Rahul Kumawat
*/

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Plugin main file
include(plugin_dir_path(__FILE__) . 'all_products.php');
include(plugin_dir_path(__FILE__) . 'cart.php');
include(plugin_dir_path(__FILE__) . 'check_out.php');

class Custom_Ecommerce_Plugin {

    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        add_action('init', array($this, 'register_custom_post_types'));
    }

    // Plugin activation function
    public function activate_plugin() {
        $this->create_pages();
        $this->create_database_tables();
        flush_rewrite_rules();
    }

    // Create custom pages with shortcodes
    public function create_pages() {
        $pages = [
            'All Products' => '[all_products]',
            'Cart' => '[cart]',
            'Orders' => '[orders]'
        ];

        foreach ($pages as $title => $shortcode) {
            if (!get_page_by_title($title)) {
                wp_insert_post([
                    'post_title' => $title,
                    'post_content' => $shortcode,
                    'post_status' => 'publish',
                    'post_type' => 'page'
                ]);
            }
        }
    }

    // Create custom database tables
    public function create_database_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $tables = [
            "CREATE TABLE {$wpdb->prefix}all_products (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                price DECIMAL(10, 2) NOT NULL,
                size VARCHAR(50) NOT NULL,
                type VARCHAR(50) NOT NULL,
                image_path VARCHAR(255) NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

            "CREATE TABLE {$wpdb->prefix}cart_products (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT(20) UNSIGNED NOT NULL,
                product_id BIGINT(20) UNSIGNED NOT NULL,
                quantity INT(11) NOT NULL,
                total_price DECIMAL(10, 2) NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

            "CREATE TABLE {$wpdb->prefix}orders (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT(20) UNSIGNED NOT NULL,
                product_id BIGINT(20) UNSIGNED NOT NULL,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                phone_number VARCHAR(20) NOT NULL,
                billing_address TEXT NOT NULL,
                shipping_address TEXT NOT NULL,
                order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",

            "CREATE TABLE {$wpdb->prefix}coupone_code (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                coupone_code VARCHAR(50) NOT NULL,
                expiry_time TIMESTAMP NOT NULL,
                discount_percent DECIMAL(5, 2) DEFAULT NULL,
                discount_amount DECIMAL(10, 2) DEFAULT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;"
        ];

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($tables as $table) {
            dbDelta($table);
        }
    }

    // Register custom post types
    public function register_custom_post_types() {
        register_post_type('products', [
            'labels' => [
                'name' => 'Products',
                'singular_name' => 'Product'
            ],
            'public' => true,
            'has_archive' => true,
            'supports' => ['title', 'editor', 'thumbnail'],
        ]);

        register_post_type('coupone_code', [
            'labels' => [
                'name' => 'Coupon Codes',
                'singular_name' => 'Coupon Code'
            ],
            'public' => true,
            'has_archive' => false,
            'supports' => ['title', 'editor'],
        ]);

        // Adding metaboxes for custom post types
        add_action('add_meta_boxes', array($this, 'add_custom_meta_boxes'));
        add_action('save_post', array($this, 'save_custom_meta_data'));
    }

    // Add meta boxes for 'products' and 'coupone_code' post types
    public function add_custom_meta_boxes() {
        add_meta_box('product_meta', 'Product Details', array($this, 'product_meta_callback'), 'products');
        add_meta_box('coupon_meta', 'Coupon Details', array($this, 'coupon_meta_callback'), 'coupone_code');
    }

    public function product_meta_callback($post) {
        ?>
        <label>Price: </label><input type="text" name="product_price" value="<?php echo get_post_meta($post->ID, 'product_price', true); ?>"><br>
        <label>Size: </label><input type="text" name="product_size" value="<?php echo get_post_meta($post->ID, 'product_size', true); ?>"><br>
        <label>Type: </label><input type="text" name="product_type" value="<?php echo get_post_meta($post->ID, 'product_type', true); ?>">
        <?php
    }

    public function coupon_meta_callback($post) {
        ?>
        <label>Coupon Code: </label><input type="text" name="coupon_code" value="<?php echo get_post_meta($post->ID, 'coupon_code', true); ?>"><br>
        <label>Expiry Time: </label><input type="datetime-local" name="coupon_expiry" value="<?php echo get_post_meta($post->ID, 'coupon_expiry', true); ?>"><br>
        <label>Discount Percent: </label><input type="text" name="discount_percent" value="<?php echo get_post_meta($post->ID, 'discount_percent', true); ?>"><br>
        <label>Discount Amount: </label><input type="text" name="discount_amount" value="<?php echo get_post_meta($post->ID, 'discount_amount', true); ?>">
        <?php
    }

    // Save custom meta data for products and coupon codes
// Save custom meta data for products and coupon codes
public function save_custom_meta_data($post_id) {
    global $wpdb;

    // For products post type
    if (get_post_type($post_id) === 'products') {
        if (isset($_POST['product_price']) && isset($_POST['product_size']) && isset($_POST['product_type'])) {
            // Sanitize and save meta data
            $price = sanitize_text_field($_POST['product_price']);
            $size = sanitize_text_field($_POST['product_size']);
            $type = sanitize_text_field($_POST['product_type']);
            $title = get_the_title($post_id);
            $description = get_post_field('post_content', $post_id);
            $image_path = wp_get_attachment_url(get_post_thumbnail_id($post_id));

            // Insert or update the data in the all_products table
            $table_name = $wpdb->prefix . 'all_products';
            $existing_product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE title = %s", $title));

            if ($existing_product) {
                // Update the existing product
                $wpdb->update(
                    $table_name,
                    [
                        'description' => $description,
                        'price' => $price,
                        'size' => $size,
                        'type' => $type,
                        'image_path' => $image_path
                    ],
                    ['title' => $title]
                );
            } else {
                // Insert new product
                $wpdb->insert(
                    $table_name,
                    [
                        'title' => $title,
                        'description' => $description,
                        'price' => $price,
                        'size' => $size,
                        'type' => $type,
                        'image_path' => $image_path
                    ]
                );
            }
        }
    }

    // For coupone_code post type
    if (get_post_type($post_id) === 'coupone_code') {
        if (isset($_POST['coupon_code']) && isset($_POST['coupon_expiry'])) {
            // Sanitize and retrieve meta data
            $coupon_code = sanitize_text_field($_POST['coupon_code']);
            $expiry_time = sanitize_text_field($_POST['coupon_expiry']);
            $discount_percent = isset($_POST['discount_percent']) ? sanitize_text_field($_POST['discount_percent']) : null;
            $discount_amount = isset($_POST['discount_amount']) ? sanitize_text_field($_POST['discount_amount']) : null;

            // Insert or update the data in the coupone_code table
            $table_name = $wpdb->prefix . 'coupone_code';
            $existing_coupon = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE coupone_code = %s", $coupon_code));

            if ($existing_coupon) {
                // Update the existing coupon
                $wpdb->update(
                    $table_name,
                    [
                        'expiry_time' => $expiry_time,
                        'discount_percent' => $discount_percent,
                        'discount_amount' => $discount_amount
                    ],
                    ['coupone_code' => $coupon_code]
                );
            } else {
                // Insert new coupon
                $wpdb->insert(
                    $table_name,
                    [
                        'coupone_code' => $coupon_code,
                        'expiry_time' => $expiry_time,
                        'discount_percent' => $discount_percent,
                        'discount_amount' => $discount_amount
                    ]
                );
            }
        }
    }
}

}


// Enqueue AJAX script
add_action('wp_enqueue_scripts', 'enqueue_ajax_script');
function enqueue_ajax_script() {
    wp_enqueue_script('ajax-script', plugin_dir_url(__FILE__) . 'ajax-script.js', array('jquery'), null, true);
    wp_localize_script('ajax-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}

// Handle AJAX request for removing product from cart
add_action('wp_ajax_remove_from_cart', 'handle_remove_from_cart_ajax');
add_action('wp_ajax_nopriv_remove_from_cart', 'handle_remove_from_cart_ajax');

function handle_remove_from_cart_ajax() {
    global $wpdb;

    $user_id = get_current_user_id() ? get_current_user_id() : session_id();
    $product_id = intval($_POST['product_id']);

    // Delete the product from cart_products table
    $table_name = $wpdb->prefix . 'cart_products';
    $deleted = $wpdb->delete($table_name, array('user_id' => $user_id, 'product_id' => $product_id));
    session_destroy();
    session_unset();
    if ($deleted) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
}

// Handle AJAX request for applying coupon code
add_action('wp_ajax_apply_coupon', 'handle_apply_coupon_ajax');
add_action('wp_ajax_nopriv_apply_coupon', 'handle_apply_coupon_ajax');

function handle_apply_coupon_ajax() {
    global $wpdb;

    $coupon_code = sanitize_text_field($_POST['coupon_code']);
    $user_id = get_current_user_id() ? get_current_user_id() : session_id();

    // Fetch coupon details
    $coupon = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}coupons WHERE code = %s", $coupon_code));

    if ($coupon) {
        // Check if coupon is expired
        if (strtotime($coupon->expiry_date) < time()) {
            wp_send_json_error('Coupon has expired.');
        }

        // // Calculate discount based on coupon type
        $discount = 0;
        $total_price = 0;

        // Fetch products from cart for the current user
        $cart_products = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}cart_products WHERE user_id = %s", $user_id));

        foreach ($cart_products as $cart_item) {
            $product_id = $cart_item->product_id;
            $quantity = $cart_item->quantity;

            // Fetch product details
            $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}all_products WHERE id = %d", $product_id));
            if ($product) {
                $price = floatval($product->price);
                $total_price += $price * $quantity;
            }
        }

        // Apply discount based on coupon type
        if ($coupon->discount_type === 'percentage') {
            $discount = ($total_price * $coupon->discount_value) / 100;
        } else if ($coupon->discount_type === 'fixed') {
            $discount = $coupon->discount_value;
        }

        // Calculate new total
        $new_total = $total_price - $discount;

        wp_send_json_success(array('new_total' => $new_total, 'discount' => $discount));
    } else {
        wp_send_json_error('Invalid coupon code.');
    }
}
// Initialize plugin
new Custom_Ecommerce_Plugin();
?>
