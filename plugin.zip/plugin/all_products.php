<?php

// Start the session at the beginning of the plugin file
add_action('init', 'start_session', 1);
function start_session() {
    if (!session_id()) {
        session_start();
    }
}

// Add shortcode for displaying all products
add_shortcode('all_products', 'display_all_products');

function display_all_products() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'all_products';
    $products = $wpdb->get_results("SELECT * FROM $table_name");

    ob_start(); // Start output buffering

    if ($products) {
        echo '<div class="all-products">';
        foreach ($products as $product) {
            $product_id = $product->id;
            $title = esc_html($product->title);
            $description = esc_html($product->description);
            $price = esc_html($product->price);
            $image_path = esc_url($product->image_path);

            echo '<div class="product">';
            echo '<img src="' . $image_path . '" alt="' . $title . '">';
            echo '<h2>' . $title . '</h2>';
            echo '<p>' . $description . '</p>';
            echo '<p>Price: ' . $price . '</p>';
            echo '<form action="" method="POST">';
            echo '<input type="hidden" name="product_id" value="' . $product_id . '">';
            echo '<input type="hidden" name="quantity" value="1">'; // Default quantity
            
            // Check if product is already added to cart
            if (isset($_SESSION['cart'][$product_id])) {
                echo '<button type="button" disabled>Added to Cart</button>';
            } else {
                echo '<button type="submit" name="add_to_cart">Add to Cart</button>';
            }

            echo '</form>';
            echo '<a href="' . get_permalink($product_id) . '" class="view-product">View Product</a>';
            echo '</div>';
        }
        echo '</div>';
    } else {
        echo '<p>No products found.</p>';
    }

    return ob_get_clean(); // Return the buffered output
}

// Handle form submission for adding product to cart
add_action('init', 'handle_add_to_cart');

function handle_add_to_cart() {
    if (isset($_POST['add_to_cart'])) {
        global $wpdb;

        $product_id = intval($_POST['product_id']);
        $user_id = get_current_user_id() ? get_current_user_id() : session_id();
        $quantity = intval($_POST['quantity']); // Get quantity from form

        // Insert into cart_products table
        $table_name = $wpdb->prefix . 'cart_products';
        $wpdb->insert($table_name, array(
            'user_id' => $user_id,
            'product_id' => $product_id,
            'quantity' => $quantity,
            'total_price' => 0 // You can calculate total price based on the product price
        ));

        // Set session variable to indicate product is added to cart
        $_SESSION['cart'][$product_id] = true;

        // Redirect to the same page to avoid form resubmission
        wp_redirect($_SERVER['REQUEST_URI']); 
        exit;
    }
}

?>