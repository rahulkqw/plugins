<?php

// Add shortcode for displaying checkout form
add_shortcode('check_out', 'display_checkout_form');

function display_checkout_form() {
    global $wpdb;
    $user_id = get_current_user_id() ? get_current_user_id() : session_id();
    $orders_table = $wpdb->prefix . 'orders';
    
    // Fetch the latest order details for the current user
    $order_details = $wpdb->get_results($wpdb->prepare("SELECT * FROM $orders_table WHERE user_id = %s ORDER BY order_time DESC", $user_id));

    ob_start(); // Start output buffering

    if ($order_details) {
        echo '<h2>Checkout</h2>';
        echo '<form id="checkout-form">';
        

        foreach ($order_details as $order) {
            echo '<h3>Order Details</h3>';
            echo '<p><strong>Product ID:</strong> ' . esc_html($order->product_id) . '</p>';
            echo '<p><strong>Name:</strong> ' . esc_html($order->name) . '</p>';
            echo '<p><strong>Email:</strong> ' . esc_html($order->email) . '</p>';
            echo '<p><strong>Phone Number:</strong> ' . esc_html($order->phone_number) . '</p>';
            echo '<p><strong>Billing Address:</strong> ' . esc_html($order->billing_address) . '</p>';
            echo '<p><strong>Shipping Address:</strong> ' . esc_html($order->shipping_address) . '</p>';
            echo '<p><strong>Order Time:</strong> ' . esc_html($order->order_time) . '</p>';
            echo '<hr>';
        }

        // Checkout form inputs
        echo '<h3>Update Your Information</h3>';
        echo '<label for="name">Name:</label>';
        echo '<input type="text" id="name" name="name" required>';
        echo '<label for="email">Email:</label>';
        echo '<input type="email" id="email" name="email" required>';
        echo '<label for="phone_number">Phone Number:</label>';
        echo '<input type="text" id="phone_number" name="phone_number" required>';
        echo '<label for="billing_address">Billing Address:</label>';
        echo '<input type="text" id="billing_address" name="billing_address" required>';
        echo '<label for="shipping_address">Shipping Address:</label>';
        echo '<input type="text" id="shipping_address" name="shipping_address" required>';
        echo '<button type="submit">Submit</button>';
        
        echo '</form>';
    } else {
        echo '<p>No orders found. Please add items to your cart and checkout.</p>';
    }

    return ob_get_clean();
}

function script() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#checkout-form').on('submit', function(e) {
            e.preventDefault();

            var user_info = {
                name: $('#name').val(),
                email: $('#email').val(),
                phone_number: $('#phone_number').val(),
                billing_address: $('#billing_address').val(),
                shipping_address: $('#shipping_address').val()
            };

            // Make an AJAX request to update the user information if needed
            $.ajax({
                type: 'POST',
                url: ajax_object.ajax_url,
                data: {
                    action: 'update_user_info', // Define an action to handle this
                    user_info: user_info
                },
                success: function(response) {
                    if (response.success) {
                        alert('Information updated successfully!');
                    } else {
                        alert('Error updating information: ' + response.data);
                    }
                }
            });
        });
    });
    </script>
    <?php
}
add_action('wp_ajax_update_user_info', 'update_user_info');

?>

