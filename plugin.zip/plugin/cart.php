<?php
// Add shortcode for displaying cart products
add_shortcode('cart', 'display_cart_products');

function display_cart_products() {
    global $wpdb;
    $user_id = get_current_user_id() ? get_current_user_id() : session_id();
    $table_name = $wpdb->prefix . 'cart_products';

    // Fetch products from cart for the current user
    $cart_products = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %s", $user_id));

    ob_start(); // Start output buffering

    if ($cart_products) {
        echo '<h2>Your Cart</h2>';
        echo '<table>';
        echo '<tr><th>Product</th><th>Quantity</th><th>Action</th></tr>';

        $total_price = 0; // Initialize total price

        foreach ($cart_products as $cart_item) {
            $product_id = $cart_item->product_id;
            $quantity = $cart_item->quantity;

            // Fetch product details
            $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}all_products WHERE id = %d", $product_id));

            if ($product) {
                $title = esc_html($product->title);
                $price = esc_html($product->price);
                $image_path = esc_url($product->image_path);
                $item_total = $price * $quantity;

                $total_price += $item_total; // Add to total price

                echo '<tr id="cart-item-' . $product_id . '">';
                echo '<td><img src="' . $image_path . '" alt="' . $title . '" style="width: 50px; height: auto;"> ' . $title . ' - Price: ' . $price . '</td>';
                echo '<td>' . $quantity . '</td>';
                echo '<td><button class="remove-from-cart" data-product-id="' . $product_id . '">Remove</button></td>';
                echo '</tr>';
            }
        }

        echo '</table>';
        echo '<h3>Total: <span id="cart-total">' . $total_price . '</span></h3>';

        // Coupon code input
        echo '<label for="coupon-code">If you have a coupon code, apply here:</label>';
        echo '<input type="text" id="coupon-code" name="coupon_code">';
        echo '<button id="apply-coupon">Apply</button>';
        echo '<div id="coupon-message"></div>';

        // Checkout button
        echo '<button id="checkout-button">Checkout</button>';

        // Checkout form (hidden)
        echo '<div id="checkout-form" style="display:none;">
                <input type="text" id="name" placeholder="Name" required>
                <input type="email" id="email" placeholder="Email" required>
                <input type="text" id="phone_number" placeholder="Phone Number" required>
                <input type="text" id="billing_address" placeholder="Billing Address" required>
                <input type="text" id="shipping_address" placeholder="Shipping Address" required>
              </div>';
    } else {
        echo '<p>Your cart is empty.</p>';
    }

    return ob_get_clean(); // Return the buffered output
}

// Enqueue scripts
function enqueue_cart_scripts() {
    wp_enqueue_script('jquery');
    wp_add_inline_script('jquery', 'var ajax_object = { ajax_url: "' . admin_url('admin-ajax.php') . '" };', 'before');
    add_action('wp_footer', 'script');
}
add_action('wp_enqueue_scripts', 'enqueue_cart_scripts');

function script() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('.remove-from-cart').on('click', function(e) {
            e.preventDefault();
            
            var product_id = $(this).data('product-id');

            $.ajax({
                type: 'POST',
                url: ajax_object.ajax_url,
                data: {
                    action: 'remove_from_cart',
                    product_id: product_id
                },
                success: function(response) {
                    if (response.success) {
                        $('#cart-item-' + product_id).remove();
                    } else {
                        alert('Error removing product from cart.');
                    }
                }
            });
        });

        // Apply coupon code
        $('#apply-coupon').on('click', function(e) {
            e.preventDefault();
            
            var coupon_code = $('#coupon-code').val();
            var cart_total = parseFloat($('#cart-total').text()); // Get current cart total

            $.ajax({
                type: 'POST',
                url: ajax_object.ajax_url,
                data: {
                    action: 'apply_coupon',
                    coupon_code: coupon_code,
                    cart_total: cart_total
                },
                success: function(response) {
                    if (response.success) {
                        $('#cart-total').text(response.data.new_total);
                        $('#coupon-message').text('Coupon applied! Discount: ' + response.data.discount);
                    } else {
                        $('#coupon-message').text(response.data);
                    }
                }
            });
        });

        // Checkout button click event
        $('#checkout-button').on('click', function(e) {
            e.preventDefault();

            // Gather user info from the hidden form
            var user_info = {
                name: $('#name').val(),
                email: $('#email').val(),
                phone_number: $('#phone_number').val(),
                billing_address: $('#billing_address').val(),
                shipping_address: $('#shipping_address').val()
            };

            var cart_products = []; // Collect cart products
            $('.remove-from-cart').each(function() {
                var product_id = $(this).data('product-id');
                var quantity = $(this).closest('tr').find('td:nth-child(2)').text();
                cart_products.push({ product_id: product_id, quantity: quantity });
            });

            // Save order to the database
            $.ajax({
                type: 'POST',
                url: ajax_object.ajax_url,
                data: {
                    action: 'process_checkout',
                    user_info: user_info,
                    cart_products: cart_products
                },
                success: function(response) {
                    if (response.success) {
                        // Redirect to checkout page
                        window.location.href = '/checkout'; // Change this to your actual checkout page URL
                    } else {
                        alert('Error processing checkout: ' + response.data);
                    }
                }
            });
        });
    });
    </script>
    <?php
}

// AJAX action handlers
add_action('wp_ajax_remove_from_cart', 'remove_from_cart');
add_action('wp_ajax_nopriv_remove_from_cart', 'remove_from_cart');

function remove_from_cart() {
    // Validate and sanitize input
    $product_id = intval($_POST['product_id']);
    $user_id = get_current_user_id() ? get_current_user_id() : session_id();
    global $wpdb;
    $table_name = $wpdb->prefix . 'cart_products';

    // Remove product from cart
    $result = $wpdb->delete($table_name, array('user_id' => $user_id, 'product_id' => $product_id));

    if ($result) {
        wp_send_json_success();
    } else {
        wp_send_json_error('Failed to remove product.');
    }
}

add_action('wp_ajax_apply_coupon', 'apply_coupon');
add_action('wp_ajax_nopriv_apply_coupon', 'apply_coupon');

function apply_coupon() {
    // Validate and sanitize input
    $coupon_code = sanitize_text_field($_POST['coupon_code']);
    // Assume a fixed discount for demonstration
    $discount = 10; // Example discount
    $new_total = 100 - $discount; // Example total calculation

    wp_send_json_success(array('new_total' => $new_total, 'discount' => $discount));
}

add_action('wp_ajax_process_checkout', 'process_checkout');
add_action('wp_ajax_nopriv_process_checkout', 'process_checkout');

function process_checkout() {
    global $wpdb;

    // Retrieve user info and cart products from the AJAX request
    $user_info = $_POST['user_info'];
    $cart_products = $_POST['cart_products'];
    $user_id = get_current_user_id() ? get_current_user_id() : session_id();
    $order_time = current_time('mysql');

    // Insert each product into the orders table
    foreach ($cart_products as $product) {
        $wpdb->insert(
            $wpdb->prefix . 'orders',
            array(
                'user_id' => $user_id,
                'product_id' => intval($product['product_id']),
                'name' => sanitize_text_field($user_info['name']),
                'email' => sanitize_email($user_info['email']),
                'phone_number' => sanitize_text_field($user_info['phone_number']),
                'billing_address' => sanitize_text_field($user_info['billing_address']),
                'shipping_address' => sanitize_text_field($user_info['shipping_address']),
                'order_time' => $order_time
            )
        );
    }

    wp_send_json_success();
}
?>